# Windows packaging changes (1.0.2)

This Windows distribution is built from Open Accounting 1.0.2,
git commit `82c91a3` (`Release 1.0.2 with the default-tax API fix.`),
which includes `0c04e9d` (API documents created without tax_rate use the
company default tax rate). The upstream Linux repository is snapshotted
into `app-src/`; Windows-only path and host defaults stay in this copy.

## Default-tax API fix (from upstream 1.0.2)

When an invoice, estimate, or sale is created or updated without `tax_rate`
(omitted, null, or blank), the company's `default_tax_rate` and matching
label are used. An explicit `tax_rate`, including `0`, stays as sent.

## `server/load-config.js`

- On Windows only, if `DATABASE_PATH`, `BACKUP_DIR`, and `UPLOAD_DIR` are
  unset, they default to `%LOCALAPPDATA%\OpenAccounting\data\` (database
  file, `backups\`, and `uploads\`). If `LOCALAPPDATA` and `APPDATA` are
  both missing, it falls back to a `data` folder next to the app, as on
  Linux.
- On Windows only, `HOST` defaults to `127.0.0.1` instead of `0.0.0.0`,
  so the desktop app does not listen on every interface unless you change it.
- Path values from the environment or `config.json` expand `%VAR%` and
  `$VAR` so a Windows config can use `%LOCALAPPDATA%\...`.
- `DEFAULT_TAX_RATE` remains `0.0775` (7.75%) and `DEFAULT_TAX_LABEL`
  remains `Sales tax 7.75%`. Rates are still editable in Settings and on
  each invoice, estimate, or sale.

## `config.example.json`

- `HOST` example is `127.0.0.1`.
- Path keys are omitted so the Windows defaults above apply if you copy
  this file to `config.json`. Portable (app-folder) paths are documented
  in `README-WINDOWS.md`.

## Added files (not in the Linux tarball)

- `start.bat` — double-click launcher; starts the bundled `node.exe` and
  opens the browser.
- `README-WINDOWS.md`, `WINDOWS-CHANGES.md`, `NOTICE.txt`,
  `SOURCE-VERSION.txt`.
- Bundled official Node.js v24.22.3 win-x64 (`runtime\node\`).
- Production `node_modules` with the win32-x64 `sqlite3` prebuild.

## Reviewed and left unchanged

The server already uses `path.join` / `path.resolve` for the database,
uploads, and static files. There are no `systemctl`, `chmod`, or other
Linux-only process calls in the runtime JavaScript. Backup and upload
directories are created with `fs.mkdirSync(..., { recursive: true })`.
`deploy/open-accounting.service`, `Dockerfile`, and `docker-compose.yml`
are Linux/Docker helpers and are omitted from the Windows zip (source
remains in the Linux project).
