# Open Accounting 1.0.2 for Windows

This is a portable Windows x64 build of Open Accounting, a small-business
accounting app (sales, invoices, estimates, bills, inventory, deposits, and
books). It is free software under the GNU General Public License v3.0 or later.

You do not need to install Node.js, Python, or any build tools. You do not
need administrator rights.

## Requirements

- Windows 10 or Windows 11, 64-bit (x86-64)
- A web browser
- Port 3003 available on this computer (you can change the port)

## Start the app

1. Unzip `open-accounting-1.0.2-windows-x64.zip` to a folder you can write to,
   for example `Documents\OpenAccounting` or `C:\OpenAccounting`. Avoid putting
   it only in a location that gets deleted (such as the Downloads folder).
2. Double-click `start.bat`.
3. A command window opens, and your default browser should open
   http://127.0.0.1:3003/ a couple of seconds later. If the browser is empty,
   wait a moment and refresh, or open that address yourself.

Leave the command window open while you use the app.

## Stop the app

Press Ctrl+C in the command window, or close that window. Your data is already
saved in the database; you do not need a separate shutdown step.

If the window was closed but the server is still running, open Task Manager,
find `node.exe` that was started from this folder, and end that task. Only
end the Open Accounting process, not other Node.js programs you may have.

## Where your data is stored

By default, on Windows, the database, backups folder, and uploads go to:

    %LOCALAPPDATA%\OpenAccounting\data

That is usually:

    C:\Users\<your name>\AppData\Local\OpenAccounting\data

The unzipped app folder can be replaced without deleting your books, as long
as you do not also delete that data folder.

To keep the data next to the app (for example on a USB drive), copy
`config.example.json` to `config.json` in the app folder and add:

    "DATABASE_PATH": "./data/accounting.db",
    "BACKUP_DIR": "./data/backups",
    "UPLOAD_DIR": "./data/uploads"

## Settings and sales tax

A new company is created with a default sales-tax rate of **7.75%**, labeled
"Sales tax 7.75%", plus a "No tax (0%)" option.

- Open **Settings** to add, edit, or remove rates, and to choose which rate is
  the default for new documents.
- Each invoice, estimate, or sale can use a different rate.

To change the seed rate used for a brand-new company, edit `DEFAULT_TAX_RATE`
(a decimal: `0.0775` means 7.75%) and `DEFAULT_TAX_LABEL` in `config.json`.
This does not rewrite companies that already exist.

## Configuration

The server reads environment variables first, then `config.json` in this
folder, then built-in defaults. A `.env` file is **not** loaded automatically.
The easiest approach on Windows is to copy `config.example.json` to
`config.json` and edit it.

Useful keys:

| Key | Default on this Windows build | Meaning |
| --- | --- | --- |
| PORT | 3003 | Listen port |
| HOST | 127.0.0.1 | Listen address. Use `0.0.0.0` only if you want other devices on your network to connect. |
| DATABASE_PATH | `%LOCALAPPDATA%\OpenAccounting\data\accounting.db` | SQLite database |
| BACKUP_DIR | `%LOCALAPPDATA%\OpenAccounting\data\backups` | Local backup folder (the app creates it; it does not upload backups) |
| UPLOAD_DIR | `%LOCALAPPDATA%\OpenAccounting\data\uploads` | Logos and favicons |
| DEFAULT_TAX_RATE | 0.0775 | Seed rate for a new company (still editable later) |
| DEFAULT_TAX_LABEL | Sales tax 7.75% | Label for that seed rate |
| REPORT_TIMEZONE | UTC | Time zone for reports |
| TLS_KEY, TLS_CERT | (empty) | Optional HTTPS certificate files |

Paths in `config.json` may be relative to the app folder, absolute, or use
Windows environment variables such as `%LOCALAPPDATA%`.

If you change `PORT` in `config.json`, also set it at the top of `start.bat`
(or set a PORT environment variable) so the browser opens the same address.

## Optional: run at sign-in (Task Scheduler)

This is optional and is not required for normal use. You can start the app
when you sign in to Windows:

1. Open Task Scheduler and create a new task.
2. Trigger: "At log on" for your user account.
3. Action: start a program, Program `cmd.exe`, arguments
   `/c start "" "C:\full\path\to\start.bat"` (use your real unzip path).
4. Configure it to run only when you are logged on, with your user account,
   and do not select "Run with highest privileges."

The command window will still appear. To hide the window or run the app as a
background service, a helper such as NSSM (the Non-Sucking Service Manager)
can run `runtime\node\node.exe` with `server\server_new.js` and a working
directory of the unzipped folder. Set the same environment variables or use
`config.json`. NSSM is not bundled here; install it yourself only if you want
this, and be aware that a Windows service typically runs under a different
account, so `%LOCALAPPDATA%` may not be your user folder unless you set
absolute paths in `config.json`.

## Updating

Unzip a newer Windows build into a new folder (or replace the app files) and
run `start.bat`. If you left the default data path unchanged, the new copy
will open the same books. Do not overwrite your `config.json` if you
customized it.

## Source, license, and runtime

- Application source is included in this zip (`server\`, `client\`,
  `scripts\`, `package.json`).
- License: GNU GPL 3.0 or later. See `LICENSE` and `NOTICE.txt`.
- This build was packaged from Open Accounting 1.0.2, git commit `82c91a3` (includes the default-tax API fix, `0c04e9d`).
- A portable official **Node.js v24.22.3** (Krypton LTS) runtime for Windows
  x64 is bundled under `runtime\node\`, with its own license file. SHA-256
  of the upstream zip was checked against `SHASUMS256.txt` from nodejs.org.
- The `sqlite3` native addon in `node_modules` is the official
  `napi-v6-win32-x64` prebuild (PE32+ x86-64).

Windows-specific code changes are listed in `WINDOWS-CHANGES.md`.

## Help

See `README.md` for general (non-Windows) install notes, Docker, and Linux
service files. Those sections are for source builds on other systems, not
for this double-click package.
