/**
 * Runtime configuration.
 * Environment variables override config.json. Relative paths are from the project root.
 *
 * Windows packaging note (Open Accounting 1.0.2 Windows x64):
 * On Windows, if DATABASE_PATH / BACKUP_DIR / UPLOAD_DIR are not set, data lives
 * under %LOCALAPPDATA%\OpenAccounting\data so the unzipped folder can stay
 * read-only and data survives replacing the app files. Set those keys in
 * config.json (relative or absolute, including %VAR% / $VAR expansions) to
 * override. HOST defaults to 127.0.0.1 on Windows.
 */
const fs = require('fs');
const path = require('path');

const PROJECT_ROOT = path.join(__dirname, '..');

function expandEnvVars(value) {
  let out = String(value);
  out = out.replace(/%([^%]+)%/g, (match, name) => {
    const v = process.env[name];
    return v != null && v !== '' ? v : match;
  });
  out = out.replace(/\$([A-Za-z_][A-Za-z0-9_]*)/g, (match, name) => {
    const v = process.env[name];
    return v != null && v !== '' ? v : match;
  });
  return out;
}

function defaultDataRoot() {
  if (process.platform === 'win32') {
    const base = process.env.LOCALAPPDATA || process.env.APPDATA;
    if (base && String(base).trim()) {
      return path.join(String(base).trim(), 'OpenAccounting', 'data');
    }
  }
  return path.join(PROJECT_ROOT, 'data');
}

function resolvePath(value, fallback) {
  const raw = value && String(value).trim() ? String(value).trim() : fallback;
  const expanded = expandEnvVars(raw);
  if (path.isAbsolute(expanded)) return path.normalize(expanded);
  return path.resolve(PROJECT_ROOT, expanded);
}

function loadConfig() {
  const filePath = process.env.CONFIG_PATH
    ? path.resolve(expandEnvVars(process.env.CONFIG_PATH))
    : path.join(PROJECT_ROOT, 'config.json');
  let file = {};
  if (fs.existsSync(filePath)) {
    file = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  }
  const env = process.env;
  const pick = (key, fallback) => {
    if (env[key] != null && String(env[key]).trim() !== '') return env[key];
    if (file[key] != null && String(file[key]).trim() !== '') return file[key];
    return fallback;
  };
  const dataRoot = defaultDataRoot();
  const defaultHost = process.platform === 'win32' ? '127.0.0.1' : '0.0.0.0';
  return {
    port: Number(pick('PORT', 3003)),
    host: String(pick('HOST', defaultHost)),
    databasePath: resolvePath(pick('DATABASE_PATH', ''), path.join(dataRoot, 'accounting.db')),
    backupDir: resolvePath(pick('BACKUP_DIR', ''), path.join(dataRoot, 'backups')),
    uploadDir: resolvePath(pick('UPLOAD_DIR', ''), path.join(dataRoot, 'uploads')),
    logLevel: String(pick('LOG_LEVEL', 'info')),
    tlsKey: String(pick('TLS_KEY', '') || ''),
    tlsCert: String(pick('TLS_CERT', '') || ''),
    reportTimezone: String(pick('REPORT_TIMEZONE', 'UTC')),
    defaultTaxRate: pick('DEFAULT_TAX_RATE', '0.0775'),
    defaultTaxLabel: String(pick('DEFAULT_TAX_LABEL', 'Sales tax 7.75%') || ''),
  };
}

module.exports = { loadConfig, PROJECT_ROOT };
