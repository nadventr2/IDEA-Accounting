@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "NODE_EXE=%~dp0runtime\node\node.exe"
if not exist "%NODE_EXE%" (
  echo Open Accounting could not find the bundled Node.js runtime:
  echo   %NODE_EXE%
  echo Unzip the package again, or place an official Node.js 24 x64 node.exe in runtime\node\
  pause
  exit /b 1
)

REM Environment variables override config.json. If PORT or HOST is not set,
REM the app uses config.json or its built-in defaults (port 3003, 127.0.0.1).
if not defined HOST set "HOST=127.0.0.1"
if not defined PORT set "PORT=3003"

echo.
echo Open Accounting 1.0.2
echo Starting at http://127.0.0.1:%PORT%/
echo Data folder: %LOCALAPPDATA%\OpenAccounting\data
echo.
echo Leave this window open while you use the app.
echo Press Ctrl+C, or close this window, to stop the server.
echo.

REM Open the browser after a short delay so the server has time to listen.
start "" /b cmd /c "timeout /t 2 /nobreak >nul && start "" http://127.0.0.1:%PORT%/"

"%NODE_EXE%" "%~dp0server\server_new.js"
set "ERR=%ERRORLEVEL%"
if not "%ERR%"=="0" (
  echo.
  echo Open Accounting exited with code %ERR%.
  echo If the port is already in use, close the other copy or set a free PORT.
  pause
)
exit /b %ERR%
